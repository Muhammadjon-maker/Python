#include <stdio.h>
#include <stdlib.h>

int main()
{
    system("cls");
    char misol[10];
    printf("Misol kiriting!\n");
    scanf("%s", &misol);
}