#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fayl = fopen(1.txt, "r");
    fscanf("")
}