import os
os.system ("cls")

popular_words = ('''When I was one I had just begun When I was two I was nearly new''', ['I', 'was', 'three', 'near'])
print(popular_words.count)