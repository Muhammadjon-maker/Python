import os
os.system ("cls")

def raqam()
    count_digits = input("Kiruvchi ma'lumotlar"): ('hi')
    print("Chiquvchi ma'lumotlar"): 
    count_digits = input("Kiruvchi ma'lumotlar"): ('who is 1st here')
    print("Chiquvchi ma'lumotlar"):
    count_digits = input("Kiruvchi ma'lumotlar"): ('my numbers is 2')
    print("Chiquvchi ma'lumotlar"):
    count_digits = input("Kiruvchi ma'lumotlar"): ('This picture is not an oil canvas painting by Danish artist Anna Petersen between 1845 and 1910 year')
    print("Chiquvchi ma'lumotlar"):
    count_digits = input("Kiruvchi ma'lumotlar"): ('')
    print("Chiquvchi ma'lumotlar"):