import os
os.system ("cls")

kun = 0;
soat = 0;
daqiqa = 0;
soniya = 0;
vaqt = open ("son", "w")
son = input("Son kiriting!")
print()